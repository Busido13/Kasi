import Link from 'next/link';
import { getStravaAuthUrl } from '@/lib/strava';

export default function Home() {
  const clientId = process.env.NEXT_PUBLIC_STRAVA_CLIENT_ID || '';
  const redirectUri = 'http://localhost:3000/api/strava/callback';

  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
      <h1 className="text-4xl font-bold mb-4 text-orange-600">Welcome to PaceFuel</h1>
      <p className="text-lg text-gray-700 mb-6 text-center max-w-xl">
        Connect your Strava account to analyze your training and get personalized fueling and hydration plans.
      </p>
      <Link
        href={getStravaAuthUrl(clientId, redirectUri)}
        className="bg-orange-500 hover:bg-orange-600 text-white font-semibold py-3 px-6 rounded-xl shadow-md transition"
      >
        Connect to Strava
      </Link>
    </main>
  );
}
