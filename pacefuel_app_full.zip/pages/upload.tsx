import { useState } from 'react';
import * as XLSX from 'xlsx';

export default function Upload() {
  const [entries, setEntries] = useState([]);
  function estimateCalories(activity, duration) {
    const MET = { Run: 10, Bike: 8, Swim: 9, Gym: 6, Rest: 1 };
    const weight = 70;
    const met = MET[activity] || 6;
    return Math.round((met * 3.5 * weight / 200) * duration);
  }
  function handleFileUpload(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: 'array' });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const json = XLSX.utils.sheet_to_json(sheet, { header: 1 });
      const parsed = json.slice(1).map(row => {
        const [date, activity, durationStr] = row;
        const duration = parseInt(durationStr);
        return { date, activity, duration, calories: estimateCalories(activity, duration) };
      });
      setEntries(parsed);
    };
    reader.readAsArrayBuffer(file);
  }
  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4 text-orange-600">Upload Training Schedule</h1>
      <input type="file" accept=".xlsx,.xls,.csv" onChange={handleFileUpload} className="mb-4" />
      <ul className="space-y-2">
        {entries.map((entry, index) => (
          <li key={index} className="bg-white p-4 rounded shadow">
            <p><strong>Date:</strong> {entry.date}</p>
            <p><strong>Activity:</strong> {entry.activity}</p>
            <p><strong>Duration:</strong> {entry.duration} min</p>
            <p><strong>Estimated Calories:</strong> {entry.calories} kcal</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
