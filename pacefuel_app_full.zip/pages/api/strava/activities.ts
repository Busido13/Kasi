import axios from 'axios';
export default async function handler(req, res) {
  const { access_token } = req.query;
  try {
    const response = await axios.get('https://www.strava.com/api/v3/athlete/activities', {
      headers: { Authorization: `Bearer ${access_token}` },
      params: { per_page: 5, page: 1 },
    });
    const data = response.data.map(a => ({
      id: a.id,
      type: a.type,
      duration: a.moving_time,
      distance: a.distance,
      elevation: a.total_elevation_gain,
      date: a.start_date,
    }));
    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch activities' });
  }
}
