import axios from 'axios';
export default async function handler(req, res) {
  const { code } = req.query;
  try {
    const tokenRes = await axios.post('https://www.strava.com/oauth/token', {
      client_id: process.env.STRAVA_CLIENT_ID,
      client_secret: process.env.STRAVA_CLIENT_SECRET,
      code,
      grant_type: 'authorization_code',
    });
    const { access_token } = tokenRes.data;
    res.redirect(`/dashboard?access_token=${access_token}`);
  } catch (error) {
    console.error('OAuth Error:', error.response?.data || error);
    res.status(500).json({ error: 'Strava OAuth failed' });
  }
}
