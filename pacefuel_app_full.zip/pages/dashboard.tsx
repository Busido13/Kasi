import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Dashboard() {
  const [activities, setActivities] = useState([]);
  useEffect(() => {
    const token = new URLSearchParams(window.location.search).get('access_token');
    if (!token) return;
    axios.get(`/api/strava/activities?access_token=${token}`).then((res) => setActivities(res.data));
  }, []);
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4 text-orange-600">Your Activities</h1>
      <ul className="space-y-2">
        {activities.map((act) => (
          <li key={act.id} className="bg-white rounded-lg p-4 shadow">
            <p><strong>Type:</strong> {act.type}</p>
            <p><strong>Duration:</strong> {Math.round(act.duration / 60)} min</p>
            <p><strong>Distance:</strong> {(act.distance / 1000).toFixed(2)} km</p>
            <p><strong>Elevation:</strong> {act.elevation} m</p>
            <p><strong>Date:</strong> {new Date(act.date).toLocaleDateString()}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
