export function getStravaAuthUrl(clientId: string, redirectUri: string) {
  return `https://www.strava.com/oauth/authorize?client_id=${clientId}&response_type=code&redirect_uri=${redirectUri}&scope=activity:read_all&approval_prompt=auto`;
}
